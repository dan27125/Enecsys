// ********************************************************************************************************
//	Enecsys Gen 1 Micro Inverter Firmware 
//
//	MIT License
//
//  Copyright 2016-2024 Daniel G. Ambrose
//
//	Daniel G. Ambrose
//	12614 Bradford Woods Dr
//	Sunset Hills, Missouri, USA 63127
//	Email: dan27125@gmail.com
//	Facetime: dambrose@amcominc.net
//	Mobile:   3145044858
//	Whatsapp: 3145044858
//
// 	Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
//	associated documentation files (the "Software"), to deal in the Software without restriction, 
//	including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
//	and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so,
//	subject to the following conditions:
//
//	The above copyright notice and this permission notice shall be included in all copies or substantial 
//	portions of the Software.
//
//	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//	SOFTWARE.
//
// ********************************************************************************************************

#include "APP_Inverter.h"


#if defined(Uses_Debug_UFB)

void debug_ufb_reset()
{
    memset( (void*) &debug_ufb,0,sizeof(debug_ufb));
}

void debug_ufb_toggle()
{
    if (debug_ufb.bits.pending)
    {
        printf("UFB pending canceled\n");
        debug_ufb_reset();
    }

    if (fault.alarm.value)
    {
        printf("Not running\n");
        return;
    }
    
    else if (debug_ufb.bits.active)
    {
        debug_ufb.bits.active=0;
        printf("UFB Normal\n");
    }
    else
    {
        debug_ufb.bits.pending=1;
        #if defined(Uses_Debug_DCV_Report)
        debug_dcv_set_telem(175,0);
        #endif

    }
}

void debug_ufb_set(Uint16 state)
{
    if (state)
    {
        printf("UFB set %u \n", state );
        debug_ufb_reset();
        debug_ufb.bits.pending=1;
        debug_ufb.bits.sample=1;
        debug_ufb.start = state;
        #if defined(Uses_Debug_DCV_Report)
        debug_dcv_set_telem(state,0);
        debug_dcv.bits.ufb_disabled=0;
        #endif
    }
    else
    {
        if (debug_ufb.bits.active==0)
        {
            if (debug_ufb.bits.pending==0)
            {
                debug_ufb_reset();
                debug_ufb.bits.sample=0;
                debug_ufb.start = 15;
                debug_ufb.bits.pending=1;                
                printf("UFB OFF @ (15)\n");
            }
            else
            {
                printf("UFB pending\n");
            }
        }
        else 
        {
            debug_ufb.bits.active=0;
            printf("UFB *** DISABLED ***\n");
        }
    }
}

void debug_ufb_start()
{
//  printf("UFB %u collected %u samples\n", debug_ufb.start, debug_ufb.limit);
    printf("UFB %u start\n", debug_ufb.start);
}


void debug_ufb_task_ms100()
{
    
}

void debug_ufb_task()
{
    if (debug_ufb.bits.notify)
    {
        debug_ufb.bits.notify=0;
        if (debug_ufb.bits.active)
            printf("UFB=OFF *** DISABLED ***\n");
        else
            printf("UFB=ON  Limit:%d\n", debug_ufb.bits.limit);
    }
}



#endif
